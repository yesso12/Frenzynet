# Edge Add-ons Listing

## Name
FlickFuse Party

## Short Description
Synchronized watch parties with chat, reactions, and quick invite links.

## Full Description
FlickFuse Party gives your community a fast watch-party flow:
- Open a streaming page
- Set a party from the extension rail
- Share invite URL
- Watch in sync with friends

Includes:
- Right-side in-page party rail
- Group chat + reaction controls
- Mic/cam quick toggles
- Party code handling and invite copy

Presented by Frenzy Nets.

## Product Site
https://frenzynets.com/FlickFuse/

## Support
https://frenzynets.com/frenzynet-updates/

## Privacy
https://frenzynets.com/legal/
