# FlickFuse Extension Privacy Policy

Last updated: 2026-03-01

FlickFuse Party is presented by Frenzy Nets.

## Data handling
- The extension stores local settings in browser local storage (room code, ad shield toggle, and recent room metadata).
- The extension does not sell personal data.
- The extension does not require account credentials to function.

## Network behavior
- The extension opens FlickFuse web URLs requested by the user.
- Optional ad shield uses browser declarative network request rules in the client browser.

## Contact
Support: https://frenzynets.com/frenzynet-updates/
Discord: https://discord.gg/4uRUSAN498
