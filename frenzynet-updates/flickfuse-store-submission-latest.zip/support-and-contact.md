# Support And Contact

- Website: https://frenzynets.com/
- FlickFuse: https://frenzynets.com/FlickFuse/
- Support hub: https://frenzynets.com/frenzynet-updates/
- Discord support: https://discord.gg/4uRUSAN498
- Billing and premium access: Message Owner/Admin in Discord
