# Release Notes

## 1.0.0
- Added in-page party rail inspired by modern watch-party UX
- Added one-click "Set a party" actions on likely watch links
- Added manual ZIP installers for Chromium and Firefox
- Added easy-install launchers for Windows/macOS/Linux
- Updated site paths to use /FlickFuse/
- Added premium messaging and Discord purchase routing
