# Firefox Add-ons Listing

## Name
FlickFuse Party

## Summary
Watch together in sync with party chat, reactions, room invites, and in-page controls.

## Description
FlickFuse Party helps groups watch streaming content together in synchronized rooms.

Features:
- One-click room start and join
- In-page right rail for party actions
- Fast invite link copy
- Live reactions and group chat flow
- Voice/cam toggles in extension rail

Created for fast setup and non-technical users.

Presented by Frenzy Nets.

## Homepage
https://frenzynets.com/FlickFuse/

## Support
https://frenzynets.com/frenzynet-updates/

## Privacy
https://frenzynets.com/legal/
